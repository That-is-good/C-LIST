#include <iostream>
#include <string>

using namespace std;

class LIST {
public:
	int len() {
		return size;
	}
	void remove(int pos);
	void insert(int pos, string s);
	void insert(int pos, char a[]);
	void append(int len);
	void clear();
	void set(int pos, string s);
	void set(int pos, char a[]);
	long double getNUMBER(int pos);
	void clear_all();
	string concat(LIST& s, string sep, int i, int j);
	string concat(LIST& s, char sep[], int i, int j);
	void sort(bool mode=false);
	string getSTRING(int pos);
	bool getBOOL(int pos);
	LIST() { size = { 1 }; }
	LIST(int lon);
	LIST(const LIST& s);
	~LIST();
	//Number
	void insert(int pos, double a);
	void insert(int pos, long double a);
	void insert(int pos, long long a);
	void insert(int pos, long a);
	void insert(int pos, short a);
	void insert(int pos, int a);
	void insert(int pos, float a);

	void set(int pos, double a);
	void set(int pos, long double a);
	void set(int pos, long long a);
	void set(int pos, long a);
	void set(int pos, short a);
	void set(int pos, int a);
	void set(int pos, float a);
	
	//Char
	void insert(int pos, char a);
	void insert(int pos, wchar_t a);
	void insert(int pos, unsigned char a);
	void insert(int pos, signed char a);

	void set(int pos, char a);
	void set(int pos, wchar_t a);
	void set(int pos, unsigned char a);
	void set(int pos, signed char a);
protected:
	int size = { 1 };
	string* table = new string[size];
};