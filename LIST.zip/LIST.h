#include <iostream>
#include <string>

using namespace std;

class LIST {
private:
	int UiKdodlSdagVva(string a) {
		bool minus = false;
		bool point = false;
		size_t point_pos;
		if (a[0] == '.')
		{
			return -1;
		}
		for (int i = 0; unsigned(i) < unsigned(a.length()); i++)
		{
			if (a.find('.') != -1)
			{
				point = true;
				point_pos = a.find('.');
			}
			if (a.find('-') != -1)
			{
				minus = true;
			}
			if (i == 0)
			{				//a.length() <= 1
							//1 >= a.length()
				if (minus && (a.length() <= 1))
				{
					return -1;
				}
				else if (point && (a.length() <= 1))
				{
					return -1;
				}
				else if (minus && point && (a.length() <= 2))
				{
					return -1;
				}
				else if (!minus && point && ((a[0] != '.') & ((a[0] < '0') | (a[0] > '9'))))
				{
					return -1;
				}
				else if (!minus && !point && ((a[0] < '0') | (a[0] > '9')))
				{
					return -1;
				}
			}
			//minus
			else if ((i > 0) && minus && !point)
			{
				if (((a[i] < '0') | (a[i] > '9')))
				{
					return -1;
				}
			}
			else if ((i > 0) && (minus == false) && !point)
			{
				if (((a[i] < '0') | (a[i] > '9')))
				{
					return -1;
				}
			}
			//point
			else if ((i > 0) && point)
			{
				if (i != point_pos)
				{
					if (((a[i] < '0') | (a[i] > '9')))
					{
						return -1;
					}
				}
				else if (i == a.length() - 1)
				{
					return -1;
				}
			}
		}
		if (!point && !minus)
		{
			return 0;
		}
		else if (point && !minus)
		{
			return 1;
		}
		else if (minus && !point)
		{
			return 2;
		}
		else
		{
			return 3;
		}
	}
public:
	template <typename number>
	bool compare01(number pos) {
		return ( typeid(pos).name() == typeid(short).name() || typeid(pos).name() == typeid(int).name() || typeid(pos).name() == typeid(long).name() || typeid(pos).name() == typeid(long long).name() || typeid(pos).name() == typeid(unsigned).name() );
	}
	template <typename number>
	bool compare02(number pos) {
		return ( typeid(pos).name() == typeid(float).name() || typeid(pos).name() == typeid(double).name() || typeid(pos).name() == typeid(long double).name() );
	}

	template <typename number>
	void append(number s)
	{
		if (s > 0 && compare01(s))
		{
			string* temp = new string[size];
			temp = table;
			size += s;
			table = new string[size + 1];
			for (int i = 0; i < size - s; i++)
			{
				table[i] = temp[i];
			}
			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void remove(number s)
	{
		if (compare01(s) && s >= 0 && s <= size)
		{
			string* temp = new string[size + 1];
			temp = table;

			size--;
			table = new string[size + 1];
			for (int i = 0; i < s; i++)
			{
				i = abs(i);
				table[i] = temp[i];
			}
			for (int i = s; i < size; i++)
			{
				i = abs(i);
				table[i] = temp[i + 1];
			}

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}


	template <typename number>
	void set(number pos, string a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			table[pos] = a;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, char a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s;
			s += a;
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, unsigned char a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s;
			s += a;
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, signed char a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s;
			s += a;
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, char a[]) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = "";
			for (int i = 0; unsigned(i) < unsigned(strlen(a)); i++)
			{
				s += a[i];
			}
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, short a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, int a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, long a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, long long a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, float a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, double a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, long double a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void set(number pos, unsigned a) {
		if (compare01(pos) && pos <= size && pos >= 0) {
			string s = to_string(a);
			table[pos] = s;
		}
		else
		{
			return;
		}
	}

	template <typename number>
	void insert(number pos, string a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = a;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, char a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s;
			s += a;
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, unsigned char a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s;
			s += a;
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, signed char a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s;
			s += a;
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, char a[]) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string* temp = new string[size];
			temp = table;

			string s = "";
			for (int i = 0; unsigned(i) < unsigned(strlen(a)); i++)
			{
				s += a[i];
			}
			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, short a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, int a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;
			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, long a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = 0; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, long long a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, float a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, double a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, long double a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}
	template <typename number>
	void insert(number pos, unsigned a) {
		if (compare01(pos) && pos >= 0 && pos <= size)
		{
			string s = to_string(a);
			string* temp = new string[size];
			temp = table;

			pos = abs(pos);
			size++;
			table = new string[size + 1];
			for (int i = pos; i < size - 1; i++)
			{
				table[i + 1] = temp[i];
			}
			for (int i = 0; i < pos; i++)
			{
				table[i] = temp[i];
			}
			table[pos] = s;

			delete[] temp;
			temp = NULL;
		}
		else
		{
			return;
		}
	}

	template <typename number>
	char* concat_getchar(LIST& s, char sep[], number i, number j)
	{
		if ((compare01(i) || compare01(j)) && i >= 0 && i <= size && j <= size && j >= i)
		{
			string temp = "";
			for (; i < j; i++)
			{
				temp += table[i];
				temp += sep;
			}
			return (char*)temp;
		}
		return (char*)"";
	}
	template <typename number, typename T>
	char* concat_getchar(LIST& s, string sep, number i, number j)
	{
		if ((compare01(i) || compare01(j)) && i >= 0 && i <= size && j <= size && j >= i)
		{
			string temp = "";
			for (; i < j; i++)
			{
				temp += table[i];
				temp += sep;
			}
			return (char*)temp;
		}
		return (char*)"";
	}
	template <typename number>
	string concat(LIST& s, char sep[], number i, number j) {
		if ((compare01(i) || compare01(j)) && i >= 0 && i <= size && j <= size && j >= i)
		{
			string temp = "";
			for (; i < j; i++)
			{
				temp += table[i];
				temp += sep;
			}
			return temp;
		}
		return "";
	}
	template <typename number>
	string concat(LIST& s, string sep, number i, number j) {
		if ((compare01(i) || compare01(j)) && i >= 0 && i <= size && j <= size && j >= i)
		{
			string temp = "";
			for (; i < j; i++)
			{
				temp += table[i];
				temp += sep;
			}
			return temp;
		}
		return "";
	}

	template <typename number>
	char* getCHAR(number pos)
	{
		if (compare01(pos) && pos >= 0 && pos < size)
		{
			try
			{
				return (char*)table[pos].c_str();
			}
			catch (exception e) { cout << e.what() << endl; }
		}
		return (char*)"";
	}
	template <typename number>
	string getSTRING(number pos) {
		if (compare01(pos) && pos >= 0 && pos < size)
		{
			try {
				return table[pos];
			}
			catch (exception e) { cout << e.what() << endl; }
		}
		return "";
	}
	template <typename number>
	long double getNUMBER(number pos) {
		long double sum = (numeric_limits<long double>::min)();
		if (compare01(pos) && pos >= 0 && pos < size)
		{
			string C = table[pos];
			int A = UiKdodlSdagVva(C);
			if (A != -1)
			{
				if (C.length() > 0) {
					try
					{
						sum = stold(C);
					}
					catch (const exception e)
					{
						cout << e.what();
					}
				}
			}
		}
		return sum;
	}
	template <typename number>
	bool getBOOL(number pos) {
		if (compare01(pos) && pos >= 0 && pos < size)
		{
			if (table[pos] == "true")
			{
				try {
					return true;
				}
				catch (exception e) { cout << e.what() << endl; }
			}
		}
		return false;
	}

	int len();
	void clear();
	void sort(bool mode = false);
	void clear_all();

	LIST() { size = { 1 }; }
	LIST(int lon);
	LIST(const LIST& s);
	~LIST();
protected:
	int size = { 1 };
	string* table = new string[size];
};