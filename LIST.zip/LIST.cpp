#include "LIST.h"

LIST::~LIST() {
	if (table != NULL)
	{
		delete[] table;
		table = NULL;
	}
}
LIST::LIST(int lon) {
	if (lon > 0)
	{
		size = lon;
		table = new string[size + 1];
	}
}
LIST::LIST(const LIST& s) {
	table = new string(*s.table);
	size = s.size;
}
void LIST::clear() {
	size = { 1 };
	delete[] table;
	table = new string[1];
}
void LIST::clear_all() {
	for (int i = 0; i < size; i++)
	{
		table[i] = "";
	}
}
void LIST::sort(bool mode) {
	//for (int i = 0; i < size; i++)
	//{
	//	cout << "p_sort[" << i << "]: " << p_sort[i] << endl;
	//}
	int *p=new int[size];
	int* p_sort = new int[size];
	for (int i = 0; i < size; i++)
	{
		p_sort[i] = i;
	}
	for (int i = 0; i < size; i++)
	{
		wchar_t sub= table[i][0];
		p[i] = sub;
	}
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = 0; j < size - i - 1; j++)
		{	
			if (mode == false)
			{
				if (p[j] > p[j + 1])
				{
					int temp02 = p[j];
					p[j] = p[j + 1];
					int temp03 = j;
					p_sort[j] = p_sort[j + 1];
					p_sort[j + 1] = temp03;
					p[j + 1] = temp02;
				}
			}
			else if(mode == true)
			{
				if (p[j] < p[j + 1])
				{
					int temp02 = p[j];
					p[j] = p[j + 1];
					int temp03 = j;
					p_sort[j] = p_sort[j + 1];
					p_sort[j + 1] = temp03;
					p[j + 1] = temp02;
				}
			}
		}
	}
	delete[] p;
	p = NULL;
	for (int i = 0; i < size; i++)
	{
		string temp04 = table[i];
		table[i] = table[p_sort[i]];
		table[p_sort[i]] = temp04;
	}
	delete[] p_sort;
	p_sort = NULL;
}
int LIST::len()
{
	return size;
}