#include "LIST.h"

int UiKdodlALDgVva(char a[], char s) {
	for (int i = 0; unsigned(i) < unsigned(strlen(a)); i++)
	{
		if (a[i] == s)
		{
			return i;
		}
	}
	return -1;
}
int UiKdodlALDgVva(string a, char s) {
	for (int i = 0; unsigned(i) < unsigned(a.length()); i++)
	{
		if (a[i] == s)
		{
			return i;
		}
	}
	return -1;
}
int UiKdodlSdagVva(string a) {
	bool minus = false;
	bool point = false;
	int point_pos;
	if (a[0] == '.')
	{
		return -1;
	}
	for (int i = 0; unsigned(i) < unsigned(a.length()); i++)
	{
		if (a.find('.') != -1)
		{
			point = true;
			point_pos = a.find('.');
		}
		if (a.find('-') != -1)
		{
			minus = true;
		}
		if (i == 0)
		{				//a.length() <= 1
						//1 >= a.length()
			if (minus && (a.length() <= 1))
			{
				return -1;
			}
			else if (point && (a.length() <= 1))
			{
				return -1;
			}
			else if (minus && point && (a.length() <= 2))
			{
				return -1;
			}
			else if (!minus && point && ((a[0] != '.') & ((a[0] < '0') | (a[0] > '9'))))
			{
				return -1;
			}
			else if (!minus && !point && ((a[0] < '0') | (a[0] > '9')))
			{
				return -1;
			}
		}
		//minus
		else if ((i > 0) && minus && !point)
		{
			if (((a[i] < '0') | (a[i] > '9')))
			{
				return -1;
			}
		}
		else if ((i > 0) && (minus == false) && !point)
		{
			if (((a[i] < '0') | (a[i] > '9')))
			{
				return -1;
			}
		}
		//point
		else if ((i > 0) && point)
		{
			if (i != point_pos)
			{
				if (((a[i] < '0') | (a[i] > '9')))
				{
					return -1;
				}
			}
			else if (i == a.length() - 1)
			{
				return -1;
			}
		}
	}
	if (!point && !minus)
	{
		return 0;
	}
	else if (point && !minus)
	{
		return 1;
	}
	else if (minus && !point)
	{
		return 2;
	}
	else
	{
		return 3;
	}
}
int UiKdodlSdagVva(char a[]) {
	bool minus = false;
	bool point = false;
	int point_pos;
	if (a[0] == '.')
	{
		return -1;
	}
	for (int i = 0; unsigned(i) < unsigned(strlen(a)); i++)
	{
		if (UiKdodlALDgVva(a, '.') != -1)
		{
			point = true;
			point_pos = UiKdodlALDgVva(a, '.');
		}
		if (UiKdodlALDgVva(a, '-') != -1)
		{
			minus = true;
		}
		if (i == 0)
		{
			if (minus && (strlen(a) <= 1))
			{
				return -1;
			}
			else if (point && (strlen(a) <= 1))
			{
				return -1;
			}
			else if (minus && point && (strlen(a) <= 2))
			{
				return -1;
			}
			else if (!minus && point && ((a[0] != '.') & ((a[0] < '0') | (a[0] > '9'))))
			{
				return -1;
			}
			else if (!minus && !point && ((a[0] < '0') | (a[0] > '9')))
			{
				return -1;
			}
		}
		//minus
		else if ((i > 0) && minus && !point)
		{
			if (((a[i] < '0') | (a[i] > '9')))
			{
				return -1;
			}
		}
		else if ((i > 0) && (minus == false) && (!point))
		{
			if (((a[i] < '0') | (a[i] > '9')))
			{
				return -1;
			}
		}
		//minus point
		else if ((i > 0) & point)
		{
			if (i != point_pos)
			{
				if (((a[i] < '0') | (a[i] > '9')))
				{
					return -1;
				}
			}
			else if (i == strlen(a) - 1)
			{
				return -1;
			}
		}
	}
	if (!point && !minus)
	{
		return 0;
	}
	else if (point && !minus)
	{
		return 1;
	}
	else if (minus && !point)
	{
		return 2;
	}
	else
	{
		return 3;
	}
}

LIST::~LIST() {
	if (table != NULL)
	{
		delete[] table;
		table = NULL;
	}
}
LIST::LIST(int lon) {
	if (lon > 0)
	{
		size = lon;
		table = new string[size + 1];
	}
}
LIST::LIST(const LIST& s) {
	table = new string(*s.table);
	size = s.size;
}
void LIST::clear() {
	size = { 1 };
	delete[] table;
	table = new string[1];
}
void LIST::clear_all() {
	for (int i = 0; i < size; i++)
	{
		table[i] = "";
	}
}
void LIST::append(int s) {
	string* temp = new string[size];
	temp = table;

	if (s > 0)
	{
		size += s;
		table = new string[size + 1];
		for (int i = 0; i < size-s; i++)
		{
			table[i] = temp[i];
		}
	}

	delete[] temp;
	temp = NULL;
}
void LIST::remove(int s) {
	if (s>=0 && s<=size)
	{
		string* temp = new string[size+1];
		temp = table;

		size--;
		table = new string[size + 1];
		for (int i = 0; i < s; i++)
		{
			i = abs(i);
			table[i] = temp[i];
		}
		for (int i = s; i < size; i++)
		{
			i = abs(i);
			table[i] = temp[i+1];
		}

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, char a[]) {
	if (pos >= 0 && pos <=size)
	{
		string* temp = new string[size];
		temp = table;

		string s = "";
		for (int i = 0; unsigned(i) < unsigned(strlen(a)); i++)
		{
			s[i] = a[i];
		}
		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size-1; i++)
		{
			table[i+1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, string s){
	if (pos >= 0 && pos <= size)
	{
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::set(int pos,string s){
	if (pos <= size && pos >= 0) {
		table[pos] = s;
	}
}
void LIST::set(int pos, char a[]) {
	if (pos <= size && pos >= 0) {
		string s = "";
		for (int i = 0; unsigned(i) < unsigned(strlen(a)); i++)
		{
			s += a[i];
		}
		table[pos] = s;
	}
}
long double LIST::getNUMBER(int pos) {
	if (pos >= 0 && pos < size)
	{
		string C = table[pos];
		int A = UiKdodlSdagVva(C);
		if (A != -1)
		{
			long double sum = 0.0;
			string buf = "";
			if (A == 1)
			{
				int pos = UiKdodlALDgVva(C, '.');
				for (int i = 0; unsigned(i) < unsigned(pos); i++)
				{
					buf += C[i];
				}
				try { sum += (stoll(buf)); }
				catch (exception e) { cout << e.what() << endl; }
				buf = "";
				int how = 0;
				for (int i = pos + 1; unsigned(i) < unsigned(C.length()); i++)
				{
					buf += C[i];
					how += 10;
				}
				try { sum += ((stoll(buf)) / how); }
				catch (exception e) { cout << e.what() << endl; }
				return sum;
			}
			else if (A == 3)
			{
				int pos = UiKdodlALDgVva(C, '.');
				for (int i = 1; unsigned(i) < unsigned(pos); i++)
				{
					buf += C[i];
				}
				try { sum -= (stoll(buf)); }
				catch (exception e) { cout << e.what() << endl; }
				buf = "";
				int how = 0;
				for (int i = pos + 1; unsigned(i) < unsigned(C.length()); i++)
				{
					buf += C[i];
					how += 10;
				}
				try { sum += -(stoll(buf)) / how; }
				catch (exception e) { cout << e.what() << endl; }
				return sum;
			}
			else if (A == 0)
			{
				try { sum += (stoll(C)); }
				catch (exception e) { cout << e.what() << endl; }
				return sum;
			}
			else
			{
				for (int i = 1; unsigned(i) < C.length(); i++)
				{
					buf += C[i];
				}
				try { sum -= (stoll(buf)); }
				catch (exception e) { cout << e.what() << endl; }
				return sum;
			}
		}
		else
		{
			return (numeric_limits<long double>::min)();
		}
	}
	else
	{
		return (numeric_limits<long double>::min)();
	}
}
string LIST::getSTRING(int pos) { 
	if (pos>=0 && pos<size)
	{
		try {
			return table[pos];
		}
		catch (exception e) { cout << e.what() << endl; }
	}
	return "";
}
bool LIST::getBOOL(int pos) {
	if (pos >= 0 && pos < size)
	{
		if (table[pos] == "true")
		{
			try {
				return true;
			}
			catch (exception e) { cout << e.what() << endl; }
		}
	}
	return false;
}
string LIST::concat(LIST& s,string sep,int i,int j) {
	if (i >= 0 && i <= size && j <= size && j>=i)
	{
		string temp = "";
		for (; i < j; i++)
		{
			temp += table[i];
			temp += sep;
		}
		return temp;
	}
	return "";
}
string LIST::concat(LIST& s, char sep[], int i, int j) {
	if (i >= 0 && i <= size && j <= size && j >= i)
	{
		string temp = "";
		for (; i < j; i++)
		{
			temp += table[i];
			temp += sep;
		}
		return temp;
	}
	return "";
}
void LIST::sort(bool mode) {
	//for (int i = 0; i < size; i++)
	//{
	//	cout << "p_sort[" << i << "]: " << p_sort[i] << endl;
	//}
	int *p=new int[size];
	int* p_sort = new int[size];
	for (int i = 0; i < size; i++)
	{
		p_sort[i] = i;
	}
	for (int i = 0; i < size; i++)
	{
		wchar_t sub= table[i][0];
		p[i] = sub;
	}
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = 0; j < size - i - 1; j++)
		{	
			if (mode == false)
			{
				if (p[j] > p[j + 1])
				{
					int temp02 = p[j];
					p[j] = p[j + 1];
					int temp03 = j;
					p_sort[j] = p_sort[j + 1];
					p_sort[j + 1] = temp03;
					p[j + 1] = temp02;
				}
			}
			else if(mode == true)
			{
				if (p[j] < p[j + 1])
				{
					int temp02 = p[j];
					p[j] = p[j + 1];
					int temp03 = j;
					p_sort[j] = p_sort[j + 1];
					p_sort[j + 1] = temp03;
					p[j + 1] = temp02;
				}
			}
		}
	}
	delete[] p;
	p = NULL;
	for (int i = 0; i < size; i++)
	{
		string temp04 = table[i];
		table[i] = table[p_sort[i]];
		table[p_sort[i]] = temp04;
	}
	delete[] p_sort;
	p_sort = NULL;
}

//Number
void LIST::set(int pos, long a) {
	if (pos <= size && pos >= 0) {
		string s = to_string(a);
		table[pos] = s;
	}
}
void LIST::set(int pos, double a) {
	if (pos <= size && pos >= 0) {
		string s = to_string(a);
		table[pos] = s;
	}
}
void LIST::set(int pos, short a) {
	if (pos <= size && pos >= 0) {
		string s = to_string(a);
		table[pos] = s;
	}
}
void LIST::set(int pos, long long a) {
	if (pos <= size && pos >= 0) {
		string s = to_string(a);
		table[pos] = s;
	}
}
void LIST::set(int pos, long double a) {
	if (pos <= size && pos >= 0) {
		string s = to_string(a);
		table[pos] = s;
	}
}
void LIST::set(int pos, float a) {
	if (pos <= size && pos >= 0) {
		string s = to_string(a);
		table[pos] = s;
	}
}
void LIST::set(int pos, int a) {
	if (pos <= size && pos >= 0) {
		string s = to_string(a);
		table[pos] = s;
	}
}

void LIST::insert(int pos, long a) {
	if (pos >= 0 && pos <= size)
	{
		string s = to_string(a);
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, long long a) {
	if (pos >= 0 && pos <= size)
	{
		string s = to_string(a);
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, long double a) {
	if (pos >= 0 && pos <= size)
	{
		string s = to_string(a);
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, short a) {
	if (pos >= 0 && pos <= size)
	{
		string s = to_string(a);
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, int a) {
	if (pos >= 0 && pos <= size)
	{
		string s = to_string(a);
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, float a) {
	if (pos >= 0 && pos <= size)
	{
		string s = to_string(a);
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, double a) {
	if (pos >= 0 && pos <= size)
	{
		string s = to_string(a);
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}

//Char
void LIST::insert(int pos, char a) {
	if (pos >= 0 && pos <= size)
	{
		string s;
		s += a;
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, wchar_t a) {
	if (pos >= 0 && pos <= size)
	{
		string s;
		s += a;
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, unsigned char a) {
	if (pos >= 0 && pos <= size)
	{
		string s;
		s += a;
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}
void LIST::insert(int pos, signed char a) {
	if (pos >= 0 && pos <= size)
	{
		string s;
		s += a;
		string* temp = new string[size];
		temp = table;

		pos = abs(pos);
		size++;
		table = new string[size + 1];
		for (int i = pos; i < size - 1; i++)
		{
			table[i + 1] = temp[i];
		}
		table[pos] = s;

		delete[] temp;
		temp = NULL;
	}
}

void LIST::set(int pos, char a) {
	if (pos <= size && pos >= 0) {
		string s;
		s += a;
		table[pos] = s;
	}
}
void LIST::set(int pos, wchar_t a) {
	if (pos <= size && pos >= 0) {
		string s;
		s += a;
		table[pos] = s;
	}
}
void LIST::set(int pos, unsigned char a) {
	if (pos <= size && pos >= 0) {
		string s;
		s += a;
		table[pos] = s;
	}
}
void LIST::set(int pos, signed char a) {
	if (pos <= size && pos >= 0) {
		string s;
		s += a;
		table[pos] = s;
	}
}