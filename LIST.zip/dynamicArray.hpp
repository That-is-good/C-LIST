#include <iostream>
using namespace std;

#pragma warning(disable:6386)

template <class T>
class dynamicArray {
public:
	dynamicArray() {
		this->size = 0;
		this->r_size = 1;
		this->p = new T[this->r_size];
	}
	dynamicArray(int lens) {
		long lenth = (long)lens;
		this->size = lenth-1;
		this->r_size = lenth;
		this->p = new T[this->r_size];
	}
	dynamicArray(long lenth) {
		this->size = lenth-1;
		this->r_size = lenth;
		this->p = new T[this->r_size];
	}
	dynamicArray(dynamicArray& a) {
		this->r_size = a.r_size;
		this->size = a.size;
		this->p = new T[a.r_size];
		for (long i = 0; i < a.r_size; i++)
		{
			this->p[i] = a.p[i];
		}
	}
	~dynamicArray() {
		if (this->p != NULL)
		{
			delete[] this->p;
			this->p = NULL;
		}
	}

	dynamicArray& operator=(const dynamicArray& a) {
		if (this->p != NULL)
		{
			delete[] this->p;
			this->p = NULL;
			this->size = 0;
			this->r_size = 0;
		}
		this->p = new T[a.r_size];
		this->size = a.size;
		this->r_size = a.r_size;
		for (long i = 0; i < a.r_size; i++)
		{
			this->p[i] = a.p[i];
		}
	}
	
	T& operator[](long index) {
		return this->p[index];
	}

	void insert(long index, T value) {
		if (index > this->r_size) { return; }
		T* temp = new T[r_size];
		temp = this->p;
		this->r_size++;
		this->size++;
		p = new T[r_size];
		for (long i = 0; i < index; i++)
		{
			this->p[i] = temp[i];
		}
		for (long i = index; i < this->size; i++)
		{
			this->p[i + 1] = temp[i];
		}
		this->p[index] = value;
		delete[] temp;
		temp = NULL;
	}
	void insert(long index) {
		if (index > this->r_size) { return; }
		T* temp = new T[r_size];
		temp = this->p;
		this->r_size++;
		this->size++;
		p = new T[r_size];
		for (long i = 0; i < index; i++)
		{
			this->p[i] = temp[i];
		}
		for (long i = index; i < this->size; i++)
		{
			this->p[i + 1] = temp[i];
		}
		delete[] temp;
		temp = NULL;
	}

	void append(T value){
		T* temp = new T[r_size];
		temp = this->p;
		this->r_size++;
		this->size++;
		p = new T[r_size];
		for (long i = 0; i < this->size; i++)
		{
			this->p[i] = temp[i];
		}
		this->p[this->size-1] = value;
		delete[] temp;
		temp = NULL;
	}

	void pop(long index){
		if (index==r_size)
		{
			return;
		}
		T* temp = new T[r_size];
		temp = this->p;
		this->size--;
		this->r_size--;
		this->p = new T[r_size];
		for (long i = 0; i < index; i++)
		{
			this->p[i] = temp[i];
		}
		for (long i = index; i < size; i++)
		{
			this->p[i] = temp[i+1];
		}
		delete[] temp;
		temp = NULL;
	}
	void pop() {
		T* temp = new T[r_size];
		temp = this->p;
		this->size--;
		this->r_size--;
		this->p = new T[r_size];
		for (long i = 0; i < size; i++)
		{
			this->p[i] = temp[i];
		}
		delete[] temp;
		temp = NULL;
	}

	void remove(T value) {
		T* temp = new T[r_size];
		for (long i = 0; i < this->size; i++)
		{
			if (p[i] == value)
			{
				temp = this->p;
				this->size--;
				this->r_size--;
				this->p = new T[r_size];
				for (long j = 0; j < i; j++)
				{
					this->p[j] = temp[j];
				}
				for (long j = i; j < size; j++)
				{
					this->p[j] = temp[j + 1];
				}
				i = 0;
			}
		}
		delete[] temp;
		temp = NULL;
	}

	long length() {
		return this->size;
	}
private:
	long size{ 0 };
	long r_size{ 1 };
	T* p = new T[r_size];
};